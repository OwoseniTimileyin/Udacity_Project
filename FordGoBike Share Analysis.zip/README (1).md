# (Dataset Exploration Title)
## by (Owoseni Timileyin)


## Dataset

> Bike sharing is a mode of transportation that is enjoyable to use, convenient, inexpensive, and good for your health. It entails the use of a large number of bicycles with distinctive designs that are docked at a series of designated locations. Unlocked bikes can be returned to any other station in the system, even if they were originally rented from a different station. People utilize bike sharing for a variety of purposes, including commuting to work or school, running errands, and getting to appointments. The dataset utilized in this project contains the bike share 2019 records, which has about 183,412 observations and 16 features.

## Summary of Findings

> In my exploration analysis, I was able to find out the followings;
-  I could observe that the members ages are below age 60
-  male gender tends to use the bikeshare service more than the female gender and any other gender
-  it is observed that the highest trips happens to be between 8 am in the morning and 5(17)pm in the evening.
-  it can be seen that subscriber users are more than the customers.

## Key Insights for Presentation

> It caught my attention, when I saw that the male gender uses the bike more, but the female gender covers the highest duration more than the male gender. Infact, out of the three categories, the male gender covers the least duration.
